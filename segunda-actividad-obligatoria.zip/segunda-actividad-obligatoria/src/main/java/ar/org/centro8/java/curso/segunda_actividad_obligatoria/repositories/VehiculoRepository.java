package ar.org.centro8.java.curso.segunda_actividad_obligatoria.repositories;

import java.util.Comparator;
import java.util.List;

import ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades.Vehiculo;
import ar.org.centro8.java.curso.segunda_actividad_obligatoria.repositories.interfaces.IVehiculos;

public class VehiculoRepository implements IVehiculos {

    @Override
    public void mostrarVehiculos(List<Vehiculo> vehiculos) {
        vehiculos.forEach(System.out::println);
    }

    @Override
    public void vehiculoCaro(List<Vehiculo> vehiculos) {
        double precioMayor = vehiculos.stream()
        .max(Comparator.comparingDouble(Vehiculo::getPrecio))
        .get().getPrecio();vehiculos.stream().filter(v -> v.getPrecio() == precioMayor)
        .forEach(v -> System.out.println("Vehículo más caro: " + v.getMarca() + " " + v.getModelo()));
    }

    @Override
    public void vehiculoBarato(List<Vehiculo> vehiculos) {
        double precioMenor = vehiculos.stream()
        .min(Comparator.comparingDouble(Vehiculo::getPrecio))
        .get().getPrecio(); vehiculos.stream().filter(v -> v.getPrecio() == precioMenor)
        .forEach(v -> System.out.println("Vehículo más barato: " + v.getMarca() + " " + v.getModelo()));
    }

    @Override
    public void buscarVehiculoLetra(List<Vehiculo> vehiculos, String letra) {
        vehiculos.stream()
        .filter(v -> v.getModelo().toLowerCase().contains(letra.toLowerCase()))
        .forEach(v -> System.out.println("Vehículo que contiene en el modelo la letra '" + letra.toUpperCase() + "': " + v.getMarca() + " " + v.getModelo() + " " + v.getPrecio()));

    }

    @Override
    public void mostrarMayorMenor(List<Vehiculo> vehiculos) {
        vehiculos.stream()
        .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
        .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));
    }

    @Override
    public void vehiculosOrdenadorPorOrdenNatural(List<Vehiculo> vehiculos) {
        vehiculos.stream()
        .sorted().forEach(System.out::println);

    }

}
