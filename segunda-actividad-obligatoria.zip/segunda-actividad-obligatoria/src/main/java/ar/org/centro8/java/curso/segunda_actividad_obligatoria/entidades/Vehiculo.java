package ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades;

import java.util.Comparator;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString

public abstract class  Vehiculo implements Comparable <Vehiculo> {

private String marca;
private String modelo;
private double precio;
@Override
public int compareTo(Vehiculo otroVehiculo) {
   
    return Comparator.comparing(Vehiculo::getMarca).thenComparing(Vehiculo::getModelo).thenComparing(Vehiculo::getPrecio).compare(this,otroVehiculo);
} 



}
