package ar.org.centro8.java.curso.segunda_actividad_obligatoria.repositories.interfaces;

import java.util.List;

import ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades.Vehiculo;

public interface IVehiculos  {
public void mostrarVehiculos(List<Vehiculo> vehiculos);
public void vehiculoCaro(List<Vehiculo> vehiculos);
public void vehiculoBarato(List<Vehiculo> vehiculos);
public void buscarVehiculoLetra(List<Vehiculo> vehiculos, String letra);

public void mostrarMayorMenor (List<Vehiculo> vehiculos);
public void vehiculosOrdenadorPorOrdenNatural (List<Vehiculo> vehiculos);


}
