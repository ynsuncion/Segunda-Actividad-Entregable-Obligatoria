package ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades;

import java.util.Comparator;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString

public abstract class Vehiculo implements Comparable<Vehiculo> {

    private String marca;
    private String modelo;
    private double precio;

    @Override
    public int compareTo(Vehiculo otroVehiculo) {
        // Compara este vehículo con otro primero por marca, por modelo y
        // finalmente por precio.
        // this. Actúa como una referencia al objeto actual
        return Comparator.comparing(Vehiculo::getMarca).thenComparing(Vehiculo::getModelo)
                .thenComparing(Vehiculo::getPrecio).compare(this, otroVehiculo);
    }

}
