package ar.org.centro8.java.curso.segunda_actividad_obligatoria.repositories;

import java.text.DecimalFormat;
import java.util.Comparator;
import java.util.List;

import ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades.Vehiculo;
import ar.org.centro8.java.curso.segunda_actividad_obligatoria.repositories.interfaces.IVehiculos;

public class VehiculoRepository implements IVehiculos {

    @Override
    public void mostrarVehiculos(List<Vehiculo> vehiculos) {
        // Recorre la lista e imprime cada vehículo usando su método toString()
        vehiculos.forEach(System.out::println);
    }

    @Override
    public void vehiculoCaro(List<Vehiculo> vehiculos) {
        // Obtiene el precio más alto de todos los vehículos utilizando un Stream y
        // Comparator.
        double precioMayor = vehiculos
                .stream()
                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get().getPrecio();

        vehiculos
                .stream()
                .filter(v -> v.getPrecio() == precioMayor)
                .forEach(v -> System.out.println("Vehículo más caro: " + v.getMarca() + " " + v.getModelo()));
    }

    @Override
    // Sobrescribe el método para mostrar el vehículo más barato de la lista.
    public void vehiculoBarato(List<Vehiculo> vehiculos) {
        double precioMenor = vehiculos
                .stream()
                .min(Comparator.comparingDouble(Vehiculo::getPrecio)) // Busca el vehículo con menor precio
                .get().getPrecio(); // // Obtiene el objeto Optional y extrae el precio
        vehiculos.stream().filter(v -> v.getPrecio() == precioMenor)
                .forEach(v -> System.out.println("Vehículo más barato: " + v.getMarca() + " " + v.getModelo()));
    }

    @Override
    // En este método uso toLowerCase(), para que puedan buscar una letra mayuscula
    // como una minuscula
    
    public void buscarVehiculoLetra(List<Vehiculo> vehiculos, String letra) {
        DecimalFormat decimal = new DecimalFormat("#,###.00");
        vehiculos.stream()
                .filter(v -> v.getModelo().toLowerCase().contains(letra.toLowerCase()))
                .forEach(v -> System.out.println("Vehículo que contiene en el modelo la letra '" + letra.toUpperCase()
                        + "': " + v.getMarca() + " " + v.getModelo() + " $" + decimal.format(v.getPrecio())));

    }

    @Override
    // Usamos reversed para cuando se muestre pueda ser de mayor a menor, ya que
    // sorted lo muestra de otra forma
    public void mostrarMayorMenor(List<Vehiculo> vehiculos) {
        vehiculos.stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));
    }

    @Override
    // Ordena la lista de vehículos según su orden natural y muestra cada uno por consola.
    public void vehiculosOrdenadorPorOrdenNatural(List<Vehiculo> vehiculos) {
        vehiculos.stream()
                .sorted().forEach(System.out::println);

    }

}
