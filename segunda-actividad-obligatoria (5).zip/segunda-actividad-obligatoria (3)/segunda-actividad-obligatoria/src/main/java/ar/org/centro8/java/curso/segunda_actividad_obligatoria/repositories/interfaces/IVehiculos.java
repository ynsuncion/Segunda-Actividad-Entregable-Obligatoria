package ar.org.centro8.java.curso.segunda_actividad_obligatoria.repositories.interfaces;

import java.util.List;

import ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades.Vehiculo;

public interface IVehiculos {
    // Este método mostrará en la consola la información de todos los vehículos de
    // la lista.
    public void mostrarVehiculos(List<Vehiculo> vehiculos);

    // Muestra al vehiculo mas caro de la lista
    public void vehiculoCaro(List<Vehiculo> vehiculos);

    // Muestra al vehiculo mas barato de la lista
    public void vehiculoBarato(List<Vehiculo> vehiculos);

    // Busca al vehiculo que tenga una letra especifica
    public void buscarVehiculoLetra(List<Vehiculo> vehiculos, String letra);

    // Este método ordenará de mayor a menor
    public void mostrarMayorMenor(List<Vehiculo> vehiculos);

    // Este método ordenará la lista de vehículos según el orden natural definido
    public void vehiculosOrdenadorPorOrdenNatural(List<Vehiculo> vehiculos);

}
