package ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades;

import java.text.DecimalFormat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class Moto extends Vehiculo {

    private String cilindrada;

    public Moto(String marca, String modelo, String cilindrada, double precio) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }

    @Override
    public String toString() {
        // DecimalFormat("#,###.00"); da formato a números decimales, mostrando los
        // miles con comas (,) y decimales.
        DecimalFormat decimal = new DecimalFormat("#,###.00");
        return "Marca: " + getMarca() + " // Modelo: " + getModelo() +
                " // Cilindrada: " + getCilindrada() + " // Precio: $" + decimal.format(getPrecio());
    }

}
