package ar.org.centro8.java.curso.segunda_actividad_obligatoria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SegundaActividadObligatoriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SegundaActividadObligatoriaApplication.class, args);
	}

}
